# -*- coding: utf-8 -*-
"""
track_dashboard.py
──────────────────────────────────────────────────────────────
[7/3 과제] 오토카 운동장 트랙 돌기 - 센서 수집 + 웹 대시보드

■ 이 프로그램이 하는 일
  1) 오토카를 조종합니다. (직접 조이스틱으로 조종 / 자동주행 버튼으로 자동 조종)
  2) 주행하는 동안 CDS(조도, 빛의 밝기를 재는) 센서 값을 계속 읽습니다.
  3) 동시에 track_odometry.py 를 이용해서 "지금 오토카가 운동장의 어디쯤에
     있는지"를 모터 속도 + 조향각으로부터 추정합니다.
  4) (센서값 + 위치) 데이터를 시간 순서대로 CSV 파일로 저장합니다.
  5) 웹 브라우저(대시보드)에서 실시간으로 주행 경로와 센서 값 그래프를
     보면서 확인할 수 있습니다.

■ 실행 방법 (오토카 터미널 = soda@192.168.0.57 에서 실행)
    1) 이 폴더를 오토카로 옮깁니다. (WSL 터미널에서 실행)
         scp -r "오토카 운동장 돌기" soda@192.168.0.57:~/
    2) 오토카에 접속합니다. (WSL 터미널에서 실행)
         ssh soda@192.168.0.57
    3) 오토카 터미널에서 이 파일을 실행합니다.
         cd ~/오토카\ 운동장\ 돌기
         python3 track_dashboard.py
    4) 아무 컴퓨터/휴대폰 브라우저에서 아래 주소로 접속합니다.
         http://192.168.0.57:5000

■ 파일 구성
    track_dashboard.py  : 이 파일. Flask 웹 서버 + 대시보드 화면.
    track_odometry.py   : 위치(오도메트리) 계산 전용 모듈.
    데이터/               : 수집한 CSV 파일이 자동으로 저장되는 폴더.
──────────────────────────────────────────────────────────────
"""

import sys
import os
import csv
import time
import threading

# pop 모듈 경로 추가 (오토카 홈 디렉터리인 /home/soda 를 파이썬 경로에 넣어줌)
sys.path.insert(0, os.path.expanduser('~'))
sys.path.insert(0, os.getcwd())

from flask import Flask, jsonify, request

from track_odometry import TrackOdometry

# ════════════════════════════════════════════════════════════
# 0. 조정 가능한 숫자값 모음 (여기 값들을 바꾸면 동작이 어떻게 바뀌는지 설명)
# ════════════════════════════════════════════════════════════

# CDS(조도) 센서가 연결된 SPI ADC 채널 번호입니다.
# - pop.Util 의 Cds 클래스는 SPI ADC 여러 채널(0~7) 중 하나에서 값을
#   읽어오는데, 실제로 CDS 센서를 몇 번 채널에 꽂았는지에 따라 값이
#   달라집니다. 대시보드를 켰을 때 CDS 값이 항상 0 이거나 이상하게
#   나오면 이 번호를 0~7 사이에서 바꿔가며 실제로 빛을 손으로 가려보고
#   값이 바뀌는 채널을 찾아주세요.
CDS_ADC_CHANNEL = 0

# 센서/위치를 얼마나 자주 측정할지 (초 단위)
# - 값이 작을수록(예: 0.05초): 더 촘촘하게 기록되어 그래프가 부드럽지만
#   CSV 파일 크기가 커지고 데이터 양이 많아집니다.
# - 값이 클수록(예: 0.5초): 데이터는 적지만 빠르게 지나가는 구간의
#   센서값 변화를 놓칠 수 있습니다.
SAMPLE_INTERVAL_SEC = 0.1  # 10Hz(1초에 10번)

# 조이스틱 조종 시, 이 시간(초) 동안 /control 신호가 안 오면 자동으로
# 정지합니다. (통신이 끊겼는데 계속 달리는 사고를 막기 위한 "워치독")
# - 값이 작을수록: 통신이 살짝만 끊겨도 바로 멈춰서 더 안전하지만,
#   네트워크가 느리면 자꾸 멈출 수 있습니다.
# - 값이 클수록: 덜 예민하게 멈추지만, 문제가 생겼을 때 더 오래
#   멈추지 않고 달릴 수 있어 위험합니다.
WATCHDOG_TIMEOUT_SEC = 0.3

# CSV/데이터를 저장할 폴더 이름 (이 스크립트와 같은 위치에 자동 생성됨)
DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "데이터")


# ════════════════════════════════════════════════════════════
# 1. 오토카 하드웨어 초기화
# ════════════════════════════════════════════════════════════
# pop/Pilot.py 내부에서 numpy(np)를 미리 import 하지 않고 사용하는 부분이
# 있어서, 터미널에서 그냥 실행하면 오류가 날 수 있습니다.
# 아래처럼 builtins(파이썬이 항상 기본으로 갖고 있는 공간)에 np를 잠깐
# 넣어줬다가 사용한 뒤 다시 지우는 방식으로 문제를 피합니다.
import builtins as _builtins
import numpy as _np
_builtins.np = _np
try:
    import torchvision as _tv
    _builtins.torchvision = _tv
except ImportError:
    pass

HAS_CAR = False
car = None
try:
    from pop.Pilot import AutoCar
    car = AutoCar()
    HAS_CAR = True
    print("[오토카] 하드웨어 연결 성공")
except Exception as _e:
    print("[오토카] 시뮬레이션 모드로 동작합니다 (하드웨어 연결 실패: %s)" % _e)

HAS_CDS = False
cds_sensor = None
try:
    from pop.Util import Cds
    cds_sensor = Cds(channel=CDS_ADC_CHANNEL)
    HAS_CDS = True
    print("[CDS 센서] 연결 성공 (채널 %d)" % CDS_ADC_CHANNEL)
except Exception as _e:
    print("[CDS 센서] 시뮬레이션 모드로 동작합니다 (센서 연결 실패: %s)" % _e)
finally:
    for _attr in ('np', 'torchvision'):
        if hasattr(_builtins, _attr):
            delattr(_builtins, _attr)


def read_cds_value():
    """
    CDS(조도) 센서 값을 하나 읽어옵니다.
    - 실제 센서가 있으면 진짜 밝기 값을 반환합니다. (값이 클수록 밝음)
    - 센서가 없는 시뮬레이션 모드에서는, 그래도 대시보드 테스트를 할 수
      있도록 시간에 따라 부드럽게 오르내리는 가짜 값을 만들어 줍니다.
    """
    if HAS_CDS:
        return cds_sensor.readAverage()
    import math
    return int(500 + 400 * math.sin(time.time() * 0.5))


# ════════════════════════════════════════════════════════════
# 2. 오토카를 조종하는 두 가지 방법을 위한 공용 상태값
#    (조이스틱 수동 조종 / 자동주행 버튼 중 어느 쪽을 쓰든
#     아래 값들만 최신 상태로 맞춰두면 됨)
# ════════════════════════════════════════════════════════════
_state_lock = threading.Lock()
_state = {
    "speed": 0,       # 0~99 사이 값 (현재 목표 속력의 크기)
    "direction": 0,   # 1=전진, -1=후진, 0=정지
    "steering": 0.0,  # -1~1 사이 값 (현재 목표 조향)
}

_last_ping = time.time()   # 조이스틱 워치독용 - 마지막으로 신호 받은 시각
_odometry = TrackOdometry()

# 주행 경로를 그리기 위해 화면에 보여줄 점들을 순서대로 저장하는 리스트
# 각 원소: {"t": 경과초, "x": x좌표(m), "y": y좌표(m), "cds": 조도값}
_trail = []
_trail_lock = threading.Lock()

# 수집(레코딩) 상태
_recording = False
_record_lock = threading.Lock()
_record_file = None
_record_writer = None
_record_path = None
_record_start_time = None

# 자동주행(이동 프로그램) 상태
_auto_running = False
_auto_thread = None


def _apply_drive(direction, speed, steering):
    """공용 상태값을 실제 오토카 명령으로 내려보내는 함수."""
    with _state_lock:
        _state["direction"] = direction
        _state["speed"] = speed
        _state["steering"] = steering

    if not car:
        return

    car.steering = steering
    if direction > 0:
        car.setSpeed(speed)
        car.forward()
    elif direction < 0:
        car.setSpeed(speed)
        car.backward()
    else:
        car.stop()


def _stop_drive():
    _apply_drive(0, 0, 0.0)


# ════════════════════════════════════════════════════════════
# 3. 배경 스레드 1 - 조이스틱 워치독
#    (조종 신호가 WATCHDOG_TIMEOUT_SEC 초 이상 안 오면 자동 정지)
# ════════════════════════════════════════════════════════════
def _watchdog_loop():
    global _last_ping
    while True:
        time.sleep(0.05)
        if car and (time.time() - _last_ping > WATCHDOG_TIMEOUT_SEC):
            _stop_drive()


# ════════════════════════════════════════════════════════════
# 4. 배경 스레드 2 - 센서/위치 샘플링
#    SAMPLE_INTERVAL_SEC 마다 한 번씩:
#      - 위치(오도메트리) 갱신
#      - CDS 값 읽기
#      - 화면에 보여줄 trail 리스트에 추가
#      - 레코딩 중이면 CSV 파일에 한 줄 기록
# ════════════════════════════════════════════════════════════
def _sampling_loop():
    global _record_writer, _record_file
    last_time = time.time()

    while True:
        time.sleep(SAMPLE_INTERVAL_SEC)

        now = time.time()
        dt = now - last_time
        last_time = now

        with _state_lock:
            speed = _state["speed"] * _state["direction"]  # 부호 있는 속도
            steering = _state["steering"]

        # 위치 갱신 (track_odometry.py 의 자전거 모델 계산)
        _odometry.update(speed=speed, steering=steering, dt=dt)

        cds_value = read_cds_value()

        point = {
            "t": round(now - (_record_start_time or now), 2),
            "x": round(_odometry.x, 3),
            "y": round(_odometry.y, 3),
            "cds": cds_value,
        }

        with _trail_lock:
            _trail.append(point)
            # 대시보드가 너무 느려지지 않도록 최근 5000개까지만 화면용으로 보관
            if len(_trail) > 5000:
                del _trail[: len(_trail) - 5000]

        with _record_lock:
            if _recording and _record_writer is not None:
                _record_writer.writerow([
                    round(now, 3),
                    point["t"],
                    _odometry.x, _odometry.y, _odometry.heading_deg,
                    speed, steering, cds_value,
                ])
                _record_file.flush()  # 중간에 프로그램이 꺼져도 데이터가 남도록 즉시 저장


# ════════════════════════════════════════════════════════════
# 5. 배경 스레드 3 - 간단한 자동주행(이동) 프로그램
#    운동장 트랙을 한 바퀴 돌 때 쓸 수 있는 아주 단순한 방식으로,
#    "일정한 속도로 전진하면서 한쪽으로 살짝 조향각을 준 상태를 유지"
#    합니다. 트랙이 원/타원에 가깝다면 이 방식만으로 계속 원을 그리며
#    돌 수 있습니다. (수동 조이스틱으로 직접 몰아도 됩니다 - 과제에서도
#    수동 조작을 허용하고 있습니다.)
# ════════════════════════════════════════════════════════════
def _auto_drive_loop(speed, steering):
    global _auto_running
    while _auto_running:
        _apply_drive(direction=1, speed=speed, steering=steering)
        time.sleep(0.1)
    _stop_drive()


# ════════════════════════════════════════════════════════════
# 6. CSV 저장 관련 함수
# ════════════════════════════════════════════════════════════
CSV_HEADER = [
    "timestamp_unix",   # 실제 시각 (1970년부터 흐른 초)
    "elapsed_sec",      # 레코딩을 시작한 뒤로부터 흐른 시간(초)
    "x_m", "y_m",        # 오도메트리로 추정한 위치 (미터)
    "heading_deg",       # 오도메트리로 추정한 진행 방향 (도)
    "speed",             # 그 순간의 부호 있는 속력 (-99~99)
    "steering",          # 그 순간의 조향 값 (-1~1)
    "cds_value",         # CDS 조도 센서 값
]


def _start_recording():
    global _recording, _record_file, _record_writer, _record_path, _record_start_time

    os.makedirs(DATA_DIR, exist_ok=True)
    filename = "track_data_" + time.strftime("%Y%m%d_%H%M%S") + ".csv"
    path = os.path.join(DATA_DIR, filename)

    f = open(path, "w", newline="", encoding="utf-8-sig")
    writer = csv.writer(f)
    writer.writerow(CSV_HEADER)

    with _record_lock:
        _record_file = f
        _record_writer = writer
        _record_path = path
        _record_start_time = time.time()
        _recording = True

    with _trail_lock:
        _trail.clear()
    _odometry.reset()

    return filename


def _stop_recording():
    global _recording, _record_file, _record_writer

    with _record_lock:
        _recording = False
        if _record_file is not None:
            _record_file.close()
        _record_file = None
        _record_writer = None


# ════════════════════════════════════════════════════════════
# 7. Flask 웹 서버
# ════════════════════════════════════════════════════════════
app = Flask(__name__)

_HTML = """<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>오토카 운동장 트랙 대시보드</title>
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    background: #0d1117; color: #c9d1d9;
    font-family: 'Segoe UI', Tahoma, sans-serif;
    min-height: 100vh; display: flex; flex-direction: column;
  }
  header {
    background: #161b22; padding: 10px 20px; display: flex;
    align-items: center; gap: 12px; border-bottom: 1px solid #30363d;
  }
  header h1 { font-size: 1.15em; color: #58a6ff; }
  .badge {
    font-size: 0.75em; padding: 2px 8px; border-radius: 12px;
    background: #21262d; border: 1px solid #30363d;
  }
  .grid {
    display: grid; grid-template-columns: 260px 1fr 320px;
    gap: 12px; padding: 12px; flex: 1;
  }
  .card {
    background: #161b22; border: 1px solid #30363d; border-radius: 10px;
    padding: 12px; display: flex; flex-direction: column; gap: 10px;
  }
  .card h2 {
    font-size: 0.8em; color: #8b949e; text-transform: uppercase;
    letter-spacing: 1px; border-bottom: 1px solid #21262d; padding-bottom: 6px;
  }
  .sl-row { display: flex; flex-direction: column; gap: 4px; }
  .sl-row label { display: flex; justify-content: space-between; font-size: 0.78em; color: #8b949e; }
  input[type=range] { width: 100%; accent-color: #58a6ff; cursor: pointer; }
  .btn {
    border: none; border-radius: 6px; padding: 9px 12px; font-size: 0.85em;
    font-weight: 600; cursor: pointer; width: 100%;
  }
  .btn-red   { background: #da3633; color: #fff; }
  .btn-green { background: #238636; color: #fff; }
  .btn-blue  { background: #1f6feb; color: #fff; }
  .btn-dark  { background: #21262d; color: #c9d1d9; border: 1px solid #30363d; }
  #joyCanvas { cursor: grab; touch-action: none; border-radius: 50%; display: block; margin: 0 auto; }
  #joyInfo { font-size: 0.8em; color: #484f58; text-align: center; font-family: monospace; }
  #pathCanvas, #cdsCanvas { background: #0d1117; border: 1px solid #21262d; border-radius: 8px; width: 100%; }
  #recStatus { font-size: 0.82em; }
  .stat { display: flex; justify-content: space-between; font-size: 0.8em; color: #8b949e; }
  .stat b { color: #c9d1d9; }
</style>
</head>
<body>

<header>
  <h1>&#127939; 오토카 운동장 트랙 대시보드</h1>
  <span class="badge" id="hwBadge">HW: 확인중...</span>
  <span class="badge" id="cdsBadge">CDS: 확인중...</span>
</header>

<div class="grid">

  <!-- 왼쪽: 조종 -->
  <div class="card">
    <h2>&#128663; 수동 조종 (조이스틱)</h2>
    <canvas id="joyCanvas" width="220" height="220"></canvas>
    <div id="joyInfo">X: 0.000 | Y: 0.000</div>
    <button class="btn btn-red" onclick="emergencyStop()">긴급 정지</button>

    <h2 style="margin-top:8px;">&#128260; 자동 주행(이동 프로그램)</h2>
    <div class="sl-row">
      <label>속력 <span id="autoSpeedVal">50</span></label>
      <input type="range" id="autoSpeed" min="0" max="99" value="50">
    </div>
    <div class="sl-row">
      <label>조향(왼쪽 -1 ~ 오른쪽 1) <span id="autoSteerVal">0.30</span></label>
      <input type="range" id="autoSteer" min="-100" max="100" value="30">
    </div>
    <button class="btn btn-blue" id="autoBtn" onclick="toggleAuto()">자동 주행 시작</button>
  </div>

  <!-- 가운데: 주행 경로 시각화 -->
  <div class="card">
    <h2>&#128506; 주행 경로 (위치별 CDS 값)</h2>
    <canvas id="pathCanvas" width="600" height="420"></canvas>
    <div class="stat"><span>현재 위치</span><b id="posInfo">x=0.00m, y=0.00m</b></div>
    <div class="stat"><span>현재 CDS 값</span><b id="cdsInfo">-</b></div>
    <h2 style="margin-top:4px;">CDS 값 변화 그래프</h2>
    <canvas id="cdsCanvas" width="600" height="140"></canvas>
  </div>

  <!-- 오른쪽: 데이터 수집 -->
  <div class="card">
    <h2>&#128190; 데이터 수집</h2>
    <div id="recStatus">대기중</div>
    <button class="btn btn-green" id="recBtn" onclick="toggleRecord()">수집 시작</button>
    <div class="stat"><span>기록된 점 개수</span><b id="ptCount">0</b></div>
    <div class="stat"><span>저장 파일</span><b id="fileInfo">-</b></div>
    <p style="font-size:0.72em; color:#484f58; line-height:1.6; margin-top:6px;">
      "수집 시작"을 누르면 이 폴더의 <b>데이터</b> 폴더 안에
      track_data_YYYYMMDD_HHMMSS.csv 이름으로 자동 저장됩니다.
      "수집 시작" 전에 먼저 조이스틱이나 자동 주행으로 오토카를
      움직여 보세요.
    </p>
  </div>

</div>

<script>
// ── 공용 fetch 함수 ──
async function api(path, body) {
  try {
    const r = await fetch(path, {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(body || {})
    });
    return await r.json();
  } catch (e) { return null; }
}

// ── 초기 상태 조회 ──
fetch('/status').then(r => r.json()).then(d => {
  const hw = document.getElementById('hwBadge');
  hw.textContent = 'HW: ' + (d.has_car ? '연결됨' : '시뮬레이션');
  hw.style.color = d.has_car ? '#2ecc71' : '#e3b341';
  const cds = document.getElementById('cdsBadge');
  cds.textContent = 'CDS: ' + (d.has_cds ? '연결됨' : '시뮬레이션');
  cds.style.color = d.has_cds ? '#2ecc71' : '#e3b341';
}).catch(function(){});

// ── 조이스틱 ──
const joyCanvas = document.getElementById('joyCanvas');
const jctx = joyCanvas.getContext('2d');
const JW = joyCanvas.width, JH = joyCanvas.height;
const JCX = JW/2, JCY = JH/2, JOUTER = JW/2 - 8, JSTICK = 30, JMAX = JOUTER - JSTICK;
let jx = 0, jy = 0, dragging = false;

function drawJoy(nx, ny) {
  jctx.clearRect(0, 0, JW, JH);
  jctx.beginPath(); jctx.arc(JCX, JCY, JOUTER, 0, Math.PI*2);
  jctx.fillStyle = '#0d1117'; jctx.fill();
  jctx.strokeStyle = '#30363d'; jctx.lineWidth = 2; jctx.stroke();
  const sx = JCX + nx*JMAX, sy = JCY - ny*JMAX;
  jctx.beginPath(); jctx.arc(sx, sy, JSTICK, 0, Math.PI*2);
  jctx.fillStyle = dragging ? '#1f6feb' : '#388bfd'; jctx.fill();
}
function relPos(e) {
  const rect = joyCanvas.getBoundingClientRect();
  const src = e.touches ? e.touches[0] : e;
  return {x: src.clientX - rect.left, y: src.clientY - rect.top};
}
function onDown(e) { dragging = true; onMove(e); }
function onMove(e) {
  if (!dragging) return;
  e.preventDefault();
  const p = relPos(e);
  let dx = p.x - JCX, dy = p.y - JCY;
  const dist = Math.hypot(dx, dy);
  if (dist > JMAX) { dx *= JMAX/dist; dy *= JMAX/dist; }
  jx = +(dx/JMAX).toFixed(3); jy = +(-(dy/JMAX)).toFixed(3);
  drawJoy(jx, jy);
  document.getElementById('joyInfo').textContent = 'X: ' + jx.toFixed(3) + ' | Y: ' + jy.toFixed(3);
}
function onUp() {
  dragging = false; jx = 0; jy = 0; drawJoy(0, 0);
  document.getElementById('joyInfo').textContent = 'X: 0.000 | Y: 0.000';
  api('/stop');
}
joyCanvas.addEventListener('mousedown', onDown);
window.addEventListener('mousemove', onMove);
window.addEventListener('mouseup', onUp);
joyCanvas.addEventListener('touchstart', onDown, {passive:false});
joyCanvas.addEventListener('touchmove', onMove, {passive:false});
joyCanvas.addEventListener('touchend', onUp);
drawJoy(0, 0);

// 50ms 마다 조이스틱 값을 서버로 전송 (드래그 중일 때만)
setInterval(function() { if (dragging) api('/control', {x: jx, y: jy}); }, 50);
// 100ms 마다 워치독용 ping 전송 (신호가 끊기면 서버가 자동 정지시킴)
setInterval(function() { api('/ping'); }, 100);

function emergencyStop() {
  dragging = false; jx = 0; jy = 0; drawJoy(0, 0);
  autoOn = false;
  document.getElementById('autoBtn').textContent = '자동 주행 시작';
  api('/stop');
}

// ── 자동 주행 ──
let autoOn = false;
document.getElementById('autoSpeed').addEventListener('input', function() {
  document.getElementById('autoSpeedVal').textContent = this.value;
});
document.getElementById('autoSteer').addEventListener('input', function() {
  document.getElementById('autoSteerVal').textContent = (this.value/100).toFixed(2);
});
function toggleAuto() {
  autoOn = !autoOn;
  const btn = document.getElementById('autoBtn');
  if (autoOn) {
    const speed = parseInt(document.getElementById('autoSpeed').value);
    const steer = parseInt(document.getElementById('autoSteer').value) / 100;
    api('/auto/start', {speed: speed, steering: steer});
    btn.textContent = '자동 주행 정지';
  } else {
    api('/auto/stop');
    btn.textContent = '자동 주행 시작';
  }
}

// ── 데이터 수집 ──
let recording = false;
function toggleRecord() {
  recording = !recording;
  const btn = document.getElementById('recBtn');
  if (recording) {
    api('/record/start').then(d => {
      document.getElementById('fileInfo').textContent = d ? d.filename : '-';
      document.getElementById('recStatus').textContent = '수집 중...';
    });
    btn.textContent = '수집 정지';
  } else {
    api('/record/stop');
    document.getElementById('recStatus').textContent = '저장 완료 (대기중)';
    btn.textContent = '수집 시작';
  }
}

// ── 경로 + CDS 그래프 그리기 ──
const pathCanvas = document.getElementById('pathCanvas');
const pctx = pathCanvas.getContext('2d');
const PW = pathCanvas.width, PH = pathCanvas.height;
// 미터를 픽셀로 바꾸는 배율. 값이 클수록 지도가 확대되어 보입니다.
// 운동장이 커서 경로가 화면 밖으로 나가면 이 값을 줄이세요.
const METERS_TO_PIXELS = 40;

const cdsCanvas = document.getElementById('cdsCanvas');
const cctx = cdsCanvas.getContext('2d');
const CW = cdsCanvas.width, CH = cdsCanvas.height;

function cdsToColor(v) {
  // CDS 값(밝을수록 큼)을 파랑(어두움) ~ 노랑(밝음) 색으로 표현
  const t = Math.max(0, Math.min(1, v / 1000));
  const r = Math.round(40 + t * 215);
  const g = Math.round(60 + t * 195);
  const b = Math.round(200 - t * 160);
  return 'rgb(' + r + ',' + g + ',' + b + ')';
}

function drawPath(trail) {
  pctx.clearRect(0, 0, PW, PH);
  const cx = PW/2, cy = PH/2;
  // 격자
  pctx.strokeStyle = 'rgba(88,166,255,0.08)'; pctx.lineWidth = 1;
  pctx.beginPath(); pctx.moveTo(cx, 0); pctx.lineTo(cx, PH); pctx.moveTo(0, cy); pctx.lineTo(PW, cy); pctx.stroke();

  for (const p of trail) {
    const px = cx + p.x * METERS_TO_PIXELS;
    const py = cy - p.y * METERS_TO_PIXELS;
    pctx.beginPath(); pctx.arc(px, py, 3, 0, Math.PI*2);
    pctx.fillStyle = cdsToColor(p.cds);
    pctx.fill();
  }
  if (trail.length > 0) {
    const last = trail[trail.length - 1];
    document.getElementById('posInfo').textContent =
      'x=' + last.x.toFixed(2) + 'm, y=' + last.y.toFixed(2) + 'm';
    document.getElementById('cdsInfo').textContent = last.cds;
  }
  document.getElementById('ptCount').textContent = trail.length;
}

function drawCdsChart(trail) {
  cctx.clearRect(0, 0, CW, CH);
  if (trail.length < 2) return;
  const recent = trail.slice(-200); // 최근 200개 점만 표시 (너무 빽빽해지지 않도록)
  const maxV = 1000;
  cctx.strokeStyle = '#58a6ff'; cctx.lineWidth = 2; cctx.beginPath();
  recent.forEach((p, i) => {
    const px = (i / (recent.length - 1)) * CW;
    const py = CH - (Math.min(p.cds, maxV) / maxV) * CH;
    if (i === 0) cctx.moveTo(px, py); else cctx.lineTo(px, py);
  });
  cctx.stroke();
}

// 300ms 마다 서버에서 최신 경로 데이터를 받아와 그림 (값이 작을수록
// 더 실시간으로 보이지만 서버에 더 자주 요청을 보내게 됩니다)
setInterval(function() {
  fetch('/track').then(r => r.json()).then(d => {
    drawPath(d.trail);
    drawCdsChart(d.trail);
  }).catch(function(){});
}, 300);
</script>
</body>
</html>
"""


@app.route('/')
def index():
    return _HTML


@app.route('/status')
def status():
    return jsonify({"has_car": HAS_CAR, "has_cds": HAS_CDS})


@app.route('/control', methods=['POST'])
def control():
    """조이스틱 좌표(x, y)를 받아서 방향/속력/조향으로 바꿔 오토카에 적용."""
    data = request.get_json(silent=True) or {}
    x = float(data.get('x', 0))
    y = float(data.get('y', 0))

    steering = max(-1.0, min(1.0, x))

    if y > 0.05:
        _apply_drive(direction=1, speed=int(y * 99), steering=steering)
    elif y < -0.05:
        _apply_drive(direction=-1, speed=int(-y * 99), steering=steering)
    else:
        _apply_drive(direction=0, speed=0, steering=steering)

    return jsonify({"status": "ok"})


@app.route('/stop', methods=['POST'])
def stop_route():
    global _auto_running
    _auto_running = False
    _stop_drive()
    return jsonify({"status": "stopped"})


@app.route('/ping', methods=['POST'])
def ping():
    global _last_ping
    _last_ping = time.time()
    return jsonify({"status": "ok"})


@app.route('/auto/start', methods=['POST'])
def auto_start():
    """간단한 자동 주행(이동 프로그램)을 시작합니다."""
    global _auto_running, _auto_thread
    data = request.get_json(silent=True) or {}
    speed = int(max(0, min(99, data.get('speed', 50))))
    steering = max(-1.0, min(1.0, float(data.get('steering', 0.0))))

    if _auto_running:
        return jsonify({"status": "already_running"})

    _auto_running = True
    _auto_thread = threading.Thread(
        target=_auto_drive_loop, args=(speed, steering), daemon=True
    )
    _auto_thread.start()
    return jsonify({"status": "started"})


@app.route('/auto/stop', methods=['POST'])
def auto_stop():
    global _auto_running
    _auto_running = False
    _stop_drive()
    return jsonify({"status": "stopped"})


@app.route('/record/start', methods=['POST'])
def record_start():
    filename = _start_recording()
    return jsonify({"status": "recording", "filename": filename})


@app.route('/record/stop', methods=['POST'])
def record_stop():
    _stop_recording()
    return jsonify({"status": "stopped", "path": _record_path})


@app.route('/track')
def track_route():
    with _trail_lock:
        # 화면에는 최근 400개 점만 보내서 브라우저가 너무 무거워지지 않게 함
        trail_copy = list(_trail[-400:])
    return jsonify({"trail": trail_copy})


# ════════════════════════════════════════════════════════════
# 8. 메인 실행부
# ════════════════════════════════════════════════════════════
if __name__ == '__main__':
    print("=" * 55)
    print("  오토카 운동장 트랙 대시보드 시작")
    print("  AutoCar HW : " + ("연결됨" if HAS_CAR else "시뮬레이션"))
    print("  CDS 센서   : " + ("연결됨" if HAS_CDS else "시뮬레이션"))
    print("=" * 55)

    threading.Thread(target=_watchdog_loop, daemon=True).start()
    threading.Thread(target=_sampling_loop, daemon=True).start()

    print("브라우저에서 http://192.168.0.57:5000 으로 접속하세요!")
    print("종료하려면 Ctrl+C")

    app.run(host='0.0.0.0', port=5000, debug=False, threaded=True, use_reloader=False)
