# -*- coding: utf-8 -*-
"""
track_odometry.py
──────────────────────────────────────────────────────────────
"오토카가 지금 운동장의 어디쯤 있는지"를 계산해주는 파일입니다.

왜 필요한가?
  오토카에는 "내가 지금 (x, y) 좌표에 있다"를 직접 알려주는 GPS 센서가
  없습니다. 대신 "모터를 얼마나 세게 돌렸는지(speed)"와
  "앞바퀴를 얼마나 꺾었는지(steering)"는 우리가 직접 값을 주고 있으므로
  이미 알고 있는 값입니다.

  이 두 값만 가지고 "짧은 시간(dt) 동안 자동차가 어느 방향으로,
  얼마나 움직였을까?"를 계속 누적해서 더하면 대략적인 위치를 추정할 수
  있습니다. 이런 방식을 "오도메트리(odometry, 주행거리 기반 위치추정)"
  라고 부릅니다. (누적 계산이라 시간이 지날수록 오차가 쌓이는 단점은
  있지만, 이번 과제처럼 짧은 시간 동안 트랙을 도는 정도에는 충분합니다.)

  사용하는 수학 모델은 자전거처럼 앞바퀴만 꺾어서 방향을 바꾸는
  자동차에 흔히 쓰이는 "자전거 모델(bicycle model)"입니다.
──────────────────────────────────────────────────────────────
"""

import math


class TrackOdometry:
    """
    오토카의 (x, y) 위치와 바라보는 방향(heading)을 계속 추적하는 클래스.

    ── 사용법 ──
        odo = TrackOdometry()
        ...(주행 루프 안에서 아주 짧은 시간(dt)마다)...
        odo.update(speed=현재_속도값, steering=현재_조향값, dt=경과시간)
        x, y, heading_deg = odo.x, odo.y, odo.heading_deg

    ── 좌표계 ──
        - 처음 프로그램을 시작한 지점을 (0, 0)으로 두고, 그 순간
          자동차가 바라보던 방향을 "+x 방향(오른쪽)"으로 둡니다.
        - x, y의 단위는 "미터(m)"입니다.
        - heading_deg 는 처음 방향을 0도로 두고, 반시계 방향을 +로 하는
          "도(degree)" 단위입니다.
    """

    # ────────────────────────────────────────────────────────
    # 아래 3개는 "실제 오토카 크기/성능에 맞춰 조정해야 하는 값"입니다.
    # 값을 바꾸면 위치 추정 결과가 어떻게 달라지는지 각 줄에 적어뒀습니다.
    # ────────────────────────────────────────────────────────

    # 앞바퀴 축 <-> 뒷바퀴 축 사이의 실제 거리 (단위: 미터)
    # - 이 값이 클수록: 같은 조향각으로 꺾어도 회전 반경이 커져서
    #   "더 완만하게" 도는 것으로 계산됩니다. (실제 자동차가 크면 크게)
    # - 값이 작을수록: 같은 조향각에서 "더 급격하게" 도는 것으로 계산됩니다.
    # - 줄자로 오토카의 앞바퀴 축과 뒷바퀴 축 사이 거리를 재서 넣어주세요.
    WHEELBASE_M = 0.20

    # setSpeed(99) 즉 "최대 속력"으로 달릴 때 실제 속도 (단위: 미터/초)
    # - 이 값이 클수록: 같은 speed 값을 줘도 "더 빨리 이동한다"고
    #   계산하기 때문에, 지도에 그려지는 이동 거리가 더 길어집니다.
    # - 값이 작을수록: 이동 거리가 더 짧게 계산됩니다.
    # - 보정(calibration) 방법:
    #     1) 평평한 바닥에서 setSpeed(50), forward()로 3초간 달리게 함
    #     2) 실제로 이동한 거리를 줄자로 잰다 (예: 1.5m)
    #     3) 그때의 speed 비율은 50/99 ≈ 0.505 이므로
    #        MAX_SPEED_MPS ≈ (1.5m / 3초) / 0.505 ≈ 0.99 m/s
    #     4) 위에서 구한 값을 아래에 넣으면 더 정확해집니다.
    MAX_SPEED_MPS = 1.0

    # steering 값이 최대(-1 또는 +1)일 때, 실제 앞바퀴가 꺾이는 각도(도)
    # - 이 값이 클수록: 같은 steering 값에서도 "더 많이 꺾인다"고
    #   계산해서 회전 반경이 더 작아집니다(더 급하게 돎).
    # - 값이 작을수록: 더 완만하게 도는 것으로 계산됩니다.
    MAX_STEER_ANGLE_DEG = 20.0

    # steering 값의 부호(+/-)가 실제로 오른쪽/왼쪽 중 어느 쪽인지는
    # 오토카 기종마다 다를 수 있습니다. 만약 지도에 그려지는 궤적이
    # 실제로 도는 방향과 반대로 나온다면 이 값을 -1 로 바꿔보세요.
    STEER_SIGN = 1

    def __init__(self):
        self.x = 0.0            # 현재 x 좌표 (미터)
        self.y = 0.0            # 현재 y 좌표 (미터)
        self.heading_rad = 0.0  # 현재 바라보는 방향 (라디안)

    @property
    def heading_deg(self):
        """heading을 사람이 읽기 편한 '도(degree)' 단위로 반환합니다."""
        return math.degrees(self.heading_rad)

    def reset(self):
        """위치를 다시 (0, 0), 방향 0도로 초기화합니다."""
        self.x = 0.0
        self.y = 0.0
        self.heading_rad = 0.0

    def update(self, speed, steering, dt):
        """
        아주 짧은 시간(dt) 동안 자동차가 이동한 만큼 위치를 갱신합니다.

        인자 설명:
            speed    : 부호가 있는 속력 값. 범위는 -99 ~ 99 를 그대로 넣으면
                       됩니다. (전진 중이면 양수, 후진 중이면 음수, 정지면 0)
                       예) setSpeed(60)을 하고 forward() 중이면 speed=60,
                           backward() 중이면 speed=-60, stop() 상태면 speed=0
            steering : -1 ~ 1 사이의 조향 값. steering()/car.steering 에
                       넣는 값을 그대로 넣으면 됩니다.
            dt       : 이번 update()가 지난번 update()로부터 얼마나
                       시간이 지났는지 (초 단위). 예: 0.1초마다 부르면
                       dt=0.1
        """
        # 1) speed(-99~99)를 실제 속도(m/s)로 변환합니다.
        #    예: speed=50 이면 50/99 ≈ 0.505, 여기에 MAX_SPEED_MPS를 곱함
        velocity_mps = (speed / 99.0) * self.MAX_SPEED_MPS

        # 2) steering(-1~1)을 실제 바퀴가 꺾인 각도(라디안)로 변환합니다.
        steer_rad = math.radians(
            steering * self.STEER_SIGN * self.MAX_STEER_ANGLE_DEG
        )

        # 3) 자전거 모델(bicycle model) 공식
        #    - 방향(heading)이 바뀌는 빠르기 = (속도 / 축간거리) * tan(조향각)
        #      => 조향각이 클수록, 속도가 빠를수록, 축간거리가 짧을수록
        #         더 빨리(급하게) 방향이 바뀝니다.
        if abs(steer_rad) > 1e-6:
            angular_velocity = (velocity_mps / self.WHEELBASE_M) * math.tan(steer_rad)
        else:
            angular_velocity = 0.0  # 조향각이 0이면 직진이므로 회전 없음

        self.heading_rad += angular_velocity * dt

        # 4) 현재 방향으로 velocity_mps 만큼 dt초 동안 이동한 거리를
        #    x, y 좌표에 누적해서 더합니다.
        self.x += velocity_mps * math.cos(self.heading_rad) * dt
        self.y += velocity_mps * math.sin(self.heading_rad) * dt
